<?php

/**
 * db.php
 *
 * @version 1.0
 * @copyright 2008 by Chlorel for XNova
 */

if ( defined('INSIDE') ) {
	include($xnova_root_path . 'db/mysql.'.$phpEx);
}

?><?php /*  Powered by OGameCN www.ogamecn.com  */ ?>