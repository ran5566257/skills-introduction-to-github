<?php

/**
 * migrateinfo.php
 *
 * @version 1.0
 * @copyright 2008 By e-Zobar for XNova
 */

$querys = array(
"INSERT INTO `{{prefix}}config` (`config_name`, `config_value`) VALUES
('game_disable', '0'),
('BuildLabWhileRun', '0'),
('LastSettedGalaxyPos', '1'),
('LastSettedSystemPos', '9'),
('LastSettedPlanetPos', '1'),
('urlaubs_modus_erz', '1'),
('OverviewExternChat', '0'),
('OverviewExternChatCmd', ''),
('OverviewBanner', '0'),
('OverviewClickBanner', '');",
);
?><?php /*  Powered by OGameCN www.ogamecn.com  */ ?>