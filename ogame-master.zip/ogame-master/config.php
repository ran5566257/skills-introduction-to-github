<?php
if(!defined("INSIDE")){ die("attemp hacking"); }
$dbsettings = Array(
"server"     => "127.0.0.1", // MySQL server name.
"user"       => "root", // MySQL username.
"pass"       => "123456", // MySQL password.
"name"       => "ogamedb1", // MySQL database name.
"prefix"     => "ogame_", // Tables prefix.
"secretword" => "XNova615547089"); // Cookies.
?>